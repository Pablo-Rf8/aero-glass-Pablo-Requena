package com.alejandromax.primeraPractica.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DatosController {

    @GetMapping("/datos")
    public String mostrarDatos(Model model) {
        model.addAttribute("Nombre", "Andres (Andokito) Angel Emmanuel");
        model.addAttribute("Apellido", "Gonzalez Garcia");
        model.addAttribute("Edad", 18);

        return "datos";
    }
}
