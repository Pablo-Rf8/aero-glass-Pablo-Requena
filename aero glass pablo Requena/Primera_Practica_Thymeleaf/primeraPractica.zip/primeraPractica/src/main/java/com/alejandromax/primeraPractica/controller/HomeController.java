package com.alejandromax.primeraPractica.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    // Esta es tu página de inicio (El Lobby)
    @GetMapping({"/", "/home"})
    public String home() {
        return "home";
    }
}